package com.cma;

public class IntegracionTest {
    
}
