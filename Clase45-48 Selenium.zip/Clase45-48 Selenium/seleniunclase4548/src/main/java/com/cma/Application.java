package com.cma;

public class Application {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
