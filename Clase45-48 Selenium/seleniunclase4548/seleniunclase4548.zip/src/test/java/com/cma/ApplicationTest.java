package com.cma;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Práctica className
 * 🎯 Estos ejercicios son de tipo fundamental, esto quiere decir que es lo
 * mínimo que necesitas resolver hoy para asegurar la comprensión del tema.
 * ¡Es momento de que apliques lo que aprendiste!
 * 1. Encuentra todos los botones que existan en una página web de tu
 * preferencia y cuéntalos.
 * 2. Encuentra cuántas imágenes tiene este producto.
 * 3. Encuentra todos los productos en este link y cuenta cuáles pertenecen a
 * Star Wars.
 */

class ApplicationTest {
    WebDriver driver = null;
    String web = "";

    @Test
    void practicaClassNameTest() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        web = "https://egg.live/es-ar/";

        driver.navigate().to(web);

        String claseBoton = "button";
        int cuentaBotones = driver.findElements(By.className(claseBoton)).size();

        System.out.println("Cantidad clase button: " + cuentaBotones);

        web = "https://www.thisisfeliznavidad.com/productos/invader-sweater/";
        driver.navigate().to(web);

        String claseImagenes = "product-slider-image";
        int cuentaImagenes = driver.findElements(By.className(claseImagenes)).size();

        System.out.println("Cantidad clase product-slider-image: " + cuentaImagenes);

    }

    @Test
    void practicaClassNameTestEj3() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        web = "https://www.thisisfeliznavidad.com/por-producto/retro-sweaters/?mpage=9";
        driver.navigate().to(web);

        String claseStarWar = "Star Wars";

        // "js-item-image";

        String claseProductos = "item-image-primary";// "item-image-secondary"

        // obtenemos lista de todos los productos (imagenes)

        List<WebElement> listaProductos = driver.findElements(By.className(claseProductos));

        System.out.println("Cantidad productos: " + listaProductos.size());

        int contarSW = 0;
        for (WebElement p : listaProductos) {
            
            if (p.getAttribute("alt").contains(claseStarWar)){
                System.out.println(p.getAttribute("alt"));
                contarSW++;
            }
        }

        System.out.println("Hay " + contarSW + " productos Star War");

    }

}
